package com.bitcrack.luchoexpress.lucho_express_tracking_orders.domain;

public enum OrderStatusEnum {
    PENDING,
    SHIPPED, 
    DELIVERED,
    CANCELLED
}
