package com.bitcrack.luchoexpress.lucho_express_tracking_orders;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LuchoExpressTrackingOrdersApplicationTests {

	@Test
	void contextLoads() {
	}

}
