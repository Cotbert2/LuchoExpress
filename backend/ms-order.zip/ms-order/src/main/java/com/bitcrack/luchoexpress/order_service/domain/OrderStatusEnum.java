package com.bitcrack.luchoexpress.order_service.domain;

public enum OrderStatusEnum {
    PENDING,
    SHIPPED,
    DELIVERED,
    CANCELLED
}
