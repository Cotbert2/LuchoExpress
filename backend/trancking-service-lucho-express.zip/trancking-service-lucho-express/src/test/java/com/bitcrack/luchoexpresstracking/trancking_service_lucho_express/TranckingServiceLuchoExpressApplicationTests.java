package com.bitcrack.luchoexpresstracking.trancking_service_lucho_express;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TranckingServiceLuchoExpressApplicationTests {

	@Test
	void contextLoads() {
	}

}
