package com.bitcrack.luchoexpresstracking.trancking_service_lucho_express;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TranckingServiceLuchoExpressApplication {

	public static void main(String[] args) {
		SpringApplication.run(TranckingServiceLuchoExpressApplication.class, args);
	}

}
